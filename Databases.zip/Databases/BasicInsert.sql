INSERT INTO {table name} ({col x name}, {col y name})
VALUES ('{value for colx}', '{value for coly}');

