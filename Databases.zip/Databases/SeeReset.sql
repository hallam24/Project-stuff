DBCC CHECKIDENT ('[{table name here}]', RESEED, {seed number here});
GO