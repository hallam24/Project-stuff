
TITLE: 
Slant - Responsive Free HTML5 template

AUTHOR:
DESIGNED & DEVELOPED by FREEHTML5.co
http://freehtml5.co/
http://twitter.com/fh5co
http://facebook.com/fh5co


CREDITS:

Bootstrap
http://getbootstrap.com/

Unsplash for Photos
http://unsplash.com/

plmd.me for Photos
http://plmd.me/

jQuery
http://jquery.com/

jQuery Easing
http://gsgd.co.uk/sandbox/jquery/easing/

Modernizr
http://modernizr.com/

Magnific Popup
http://dimsemenov.com/plugins/magnific-popup/

Google Fonts
https://www.google.com/fonts/

Icomoon Entypo
https://icomoon.io/app/
http://www.entypo.com/

Respond JS
https://github.com/scottjehl/Respond/blob/master/LICENSE-MIT

countTo JS
https://github.com/mhuggins/jquery-countTo

Stellar JS
http://markdalgleish.com/projects/stellar.js

animate.css
http://daneden.me/animate

jQuery Waypoint
https://github.com/imakewebthings/waypoints/blog/master/licenses.txt


